#!/usr/bin/env python3
"""Independent integer models for the memory-first brief. No RTL or fit claims.
Run: python check_arithmetic.py --output report.json
Uses only Python's standard library. Deterministic seeds; fails on first error.
"""
from __future__ import annotations
import argparse, hashlib, json, math, random, time
from pathlib import Path
from typing import Callable

Q = tuple((n*n)//4 for n in range(512))
I32_MIN, I32_MAX = -(1 << 31), (1 << 31)-1
RESULTS: list[dict] = []


def s32(x: int) -> int:
    return ((x + (1 << 31)) & ((1 << 32)-1)) - (1 << 31)


def trunc_div(n: int, d: int) -> int:
    if d <= 0:
        raise ValueError('positive divisor required')
    return n//d if n >= 0 else -((-n)//d)


def sat32(x: int) -> int:
    return max(I32_MIN, min(I32_MAX, x))


def qmul(a: int, b: int, table: tuple[int, ...] = Q) -> int:
    if not (0 <= a <= 255 and 0 <= b <= 255):
        raise ValueError('byte operands required')
    return table[a+b] - table[abs(a-b)]


def smul_byte(d: int, b: int) -> int:
    return (-1 if d < 0 else 1) * qmul(abs(d), b)


def check(name: str, fn: Callable[[], dict]) -> None:
    start = time.perf_counter()
    extra = fn()
    RESULTS.append({'name': name, 'status': 'pass', **extra,
                    'seconds': round(time.perf_counter()-start, 4)})


def qs_exhaustive() -> dict:
    for a in range(256):
        for b in range(256):
            assert qmul(a, b) == a*b, (a,b)
    mutant = list(Q); mutant[2] ^= 1
    assert qmul(1,1,tuple(mutant)) != 1
    assert max(Q) == 65280
    return {'pairs_exhaustive':65536, 'table_entries':512,
            'mutant_detected':'Q[2] corrupted; product 1*1 differs'}


def bilerp_ref(t: tuple[int,int,int,int], u: int, v: int) -> int:
    t00,t10,t01,t11=t
    a=(t00 << 8)+(t10-t00)*u
    b=(t01 << 8)+(t11-t01)*u
    return ((a << 8)+(b-a)*v+32768) >> 16


def bilerp_rom(t: tuple[int,int,int,int], u: int, v: int) -> int:
    t00,t10,t01,t11=t
    a=(t00 << 8)+smul_byte(t10-t00,u)
    b=(t01 << 8)+smul_byte(t11-t01,u)
    assert 0 <= a <= 65280 and 0 <= b <= 65280
    d=b-a; m=abs(d)
    assert m <= 65280
    p=qmul(m & 255,v)+(qmul(m >> 8,v)<<8)
    if d < 0: p=-p
    return ((a<<8)+p+32768)>>16


def bilerp_checks() -> dict:
    rng=random.Random(95001); n=0
    from itertools import product
    for t in product((0,1,127,254,255), repeat=4):
        for u,v in product((0,1,127,128,254,255), repeat=2):
            assert bilerp_ref(t,u,v)==bilerp_rom(t,u,v)
            n+=1
    for _ in range(50000):
        t=tuple(rng.randrange(256) for _ in range(4))
        u,v=rng.randrange(256),rng.randrange(256)
        assert bilerp_ref(t,u,v)==bilerp_rom(t,u,v); n+=1
    witness=None
    for _ in range(10000):
        t=tuple(rng.randrange(256) for _ in range(4)); u,v=rng.randrange(256),rng.randrange(256)
        a=((t[0]<<8)+(t[1]-t[0])*u+128)>>8
        b=((t[2]<<8)+(t[3]-t[2])*u+128)>>8
        wrong=((a<<8)+(b-a)*v+128)>>8
        right=bilerp_ref(t,u,v)
        if wrong!=right:
            witness={'texels':t,'fu':u,'fv':v,'correct':right,'early_round':wrong}; break
    assert witness
    return {'cases':n, 'early_rounding_mutant_counterexample':witness}


def fog_checks() -> dict:
    for d in range(-255,256):
        for a in range(256):
            assert smul_byte(d,a)==d*a
            assert (smul_byte(d,a)+128)>>8 == (d*a+128)>>8
    # Restoring the sign AFTER rounding is wrong at a negative tie.
    assert ((-1*128+128)>>8)==0
    assert -((1*128+128)>>8)==-1
    rng=random.Random(95002)
    for _ in range(20000):
        c,fog=rng.randrange(256),rng.randrange(256)
        f=rng.randrange(-(1<<31),1<<31); en=rng.choice((False,True))
        f8=max(0,min(255,(f+128)>>8)); amt=255-f8 if en else 0
        val=max(0,min(255,c+((smul_byte(fog-c,amt)+128)>>8)))
        ref=max(0,min(255,c+(((fog-c)*amt+128)>>8)))
        assert val==ref
        if not en or amt==0: assert val==c
    return {'signed_difference_amount_pairs':511*256,'full_channel_cases':20000,
            'negative_rounding_mutant_counterexample':{'diff':-1,'amt':128,'correct_delta':0,'wrong_delta':-1}}


def hybrid(a: int, b: int) -> int:
    mask=(1<<26)-1
    al,ah=a & mask,a>>26; bl,bh=b & mask,b>>26
    assert 0<=al<1<<26 and -32<=ah<=31
    assert 0<=bl<1<<26 and -32<=bh<=31
    raw=bh & 63
    small=sum((al<<j) for j in range(5) if (raw>>j)&1)
    if raw & 32: small-=al<<5
    assert small==al*bh
    h=ah*b; assert -(1<<37)<=h<(1<<37)
    cross=small+h
    assert -(1<<38)<=cross<(1<<38)
    out=al*bl+(cross<<26)
    assert -(1<<63)<=out<(1<<63)
    return out


def hybrid_checks() -> dict:
    values=[I32_MIN,I32_MIN+1,-(1<<30),-(1<<26)-1,-(1<<26),-1,0,1,(1<<26)-1,(1<<26),I32_MAX]
    n=0
    for a in values:
        for b in values:
            assert hybrid(a,b)==a*b; n+=1
    rng=random.Random(95003)
    for _ in range(100000):
        a,b=rng.randrange(-(1<<31),1<<31),rng.randrange(-(1<<31),1<<31)
        assert hybrid(a,b)==a*b; n+=1
    # A mutant interpreting the high limb as unsigned mishandles -1.
    a,b=-1,17; ah_bad=((a & ((1<<32)-1))>>26)
    wrong=(a & ((1<<26)-1))*(b & ((1<<26)-1))+(((a & ((1<<26)-1))*(b>>26)+ah_bad*b)<<26)
    assert wrong!=a*b
    return {'full_s32_pairs':n,'wrong_signed_high_limb_detected':True}


def table_product(x: int, k: int, width: int) -> int:
    # Only 32 and 33 are used by viewport/fog-factor models.
    assert width in (32,33) and -(1<<(width-1))<=x<(1<<(width-1))
    lo=x & ((1<<32)-1)
    out=sum(((lo>>(8*j)) & 255)*k << (8*j) for j in range(4))
    # s33 has four low bytes plus one sign bit; s32 sign correction is same.
    if x<0: out-=k<<32
    return out


def coefficients_checks() -> dict:
    rng=random.Random(95004)
    for _ in range(50000):
        x=rng.randrange(-(1<<31),1<<31); extent=rng.randrange(4096)
        assert table_product(x,extent,32)==x*extent
        far=rng.randrange(-(1<<31),1<<31); w=rng.randrange(1<<31)
        k=rng.randrange(-(1<<31),1<<31); d=far-w
        assert -(1<<32)<=d<(1<<32)
        p=table_product(d,k,33); assert p==d*k
        assert max(0,min(65536,(p+32768)>>16))==max(0,min(65536,(d*k+32768)>>16))
    return {'viewport_cases':50000,'fog_factor_cases':50000}


def distributed_dot(coeff: tuple[int,...], values: tuple[int,...], width: int) -> int:
    assert len(coeff)==len(values)
    table=[sum(c for j,c in enumerate(coeff) if (mask>>j)&1) for mask in range(1<<len(coeff))]
    out=0
    for k in range(width):
        mask=sum((((x & ((1<<width)-1))>>k)&1)<<j for j,x in enumerate(values))
        out += table[mask]*( -(1<<k) if k==width-1 else (1<<k))
    return out


def distributed_checks() -> dict:
    rng=random.Random(95005)
    for _ in range(6000):
        c=tuple(rng.randrange(-(1<<32),1<<32) for _ in range(3))+(rng.randrange(1<<34),)
        x=tuple(rng.randrange(-(1<<31),1<<31) for _ in range(4))
        assert distributed_dot(c,x,32)==sum(a*b for a,b in zip(c,x))
        # Attribute setup: full signed attribute domain and broad safe coefficient widths.
        ca=tuple(rng.randrange(-(1<<45),1<<45) for _ in range(3))
        va=x[:3]
        assert distributed_dot(ca,va,32)==sum(a*b for a,b in zip(ca,va))
        grad=tuple(rng.randrange(-(1<<71),1<<71) for _ in range(2))
        xy=tuple(rng.randrange(-2048,2048) for _ in range(2))
        assert distributed_dot(grad,xy,12)==sum(a*b for a,b in zip(grad,xy))
    assert distributed_dot((7,),(-1,),32)==-7
    return {'cull_dot_cases':6000,'attribute_dot_cases':6000,'tile_seed_dot_cases':6000,
            'negative_top_bit_control':True}


def reduce_iterative(v: tuple[int,int,int]) -> tuple[tuple[int,int,int],int]:
    k=0
    while max(abs(x) for x in v)>=(1<<30):
        v=tuple(x>>1 for x in v); k+=1
    return v,k


def reduce_fast(v: tuple[int,int,int]) -> tuple[tuple[int,int,int],int]:
    m=max(abs(x) for x in v)
    k=max(0,m.bit_length()-30)
    out=tuple(x>>k for x in v)
    if max(abs(x) for x in out)>=(1<<30):
        out=tuple(x>>1 for x in out); k+=1
    return out,k


def square30(m: int) -> int:
    assert 0<=m<(1<<30)
    lo=m & ((1<<15)-1); hi=m>>15
    return lo*lo+((2*lo*hi)<<15)+((hi*hi)<<30)


def normal_checks() -> dict:
    rng=random.Random(95006)
    boundary=(-(1<<31)+1,0,0)
    correct,k=reduce_fast(boundary)
    naive=tuple(x>>max(0,max(abs(y) for y in boundary).bit_length()-30) for x in boundary)
    assert correct!=naive and correct==reduce_iterative(boundary)[0]
    for _ in range(25000):
        v=tuple(rng.randrange(-(1<<46),1<<46) for _ in range(3))
        a=reduce_iterative(v); b=reduce_fast(v); assert a==b
        m2=sum(square30(abs(x)) for x in a[0])
        assert m2==sum(x*x for x in a[0]) and m2<(1<<62)
    # Input-domain bounds: extreme signed32 coefficients and signed8 normals.
    from itertools import product
    for coeff in product((I32_MIN,I32_MAX),repeat=3):
        for norm in product((-128,127),repeat=3):
            dot=sum(a*b for a,b in zip(coeff,norm)); assert -(1<<40)<=dot<(1<<40)
            for w in (0,1,32,63,64):
                other=-dot
                blend=w*dot+(64-w)*other
                assert -(1<<46)<=blend<(1<<46)
                assert blend==(other<<6)+w*(dot-other)
    return {'vectors':25000,'negative_boundary':{'input':boundary,'correct':correct,'naive_wrong':naive},
            'legal_weight_and_dot_extremes':True}


def dda_positions(a: int,b: int) -> list[int]:
    span=b-a; q,r=divmod(span,32)
    flo,rem=0,16; n=16; out=[]
    for _ in range(33):
        trunc=flo+int(n<0 and rem!=0)
        out.append(s32(a+trunc))
        flo+=q; rem+=r
        if rem>=32: flo+=1; rem-=32
        n+=span
    return out


def dda_checks() -> dict:
    rng=random.Random(95007)
    cases=[(I32_MIN,I32_MAX),(I32_MAX,I32_MIN),(0,-1),(13,-12345),(0,0)]
    cases += [(rng.randrange(-(1<<31),1<<31),rng.randrange(-(1<<31),1<<31)) for _ in range(4000)]
    for a,b in cases:
        ref=[s32(a+trunc_div((b-a)*i+16,32)) for i in range(33)]
        assert dda_positions(a,b)==ref,(a,b)
    assert trunc_div(-1,32)!=(-1>>5)
    for _ in range(200):
        a,b,c,d=[rng.randrange(-(1<<31),1<<31) for _ in range(4)]
        cx,cz=[rng.randrange(-(1<<31),1<<31) for _ in range(2)]
        xs,zs=dda_positions(a,b),dda_positions(c,d)
        x2=[(x-cx)**2 for x in xs]; z2=[(z-cz)**2 for z in zs]
        for i in range(33):
            for j in range(33):
                assert x2[i]+z2[j]==(xs[i]-cx)**2+(zs[j]-cz)**2
    return {'extent_pairs':len(cases),'positions_per_pair':33,'separable_stamps':200,
            'all_vertices_per_stamp':1089,'negative_truncation_mutant_detected':True}


def g_bake(depth: int, s: int) -> int:
    return (sat32((depth*s+32768)>>16)+128)>>8


def bake_round_checks() -> dict:
    rng=random.Random(95008); fused=None; difference=None
    for _ in range(50000):
        a,b,c=[rng.randrange(-(1<<31),1<<31) for _ in range(3)]
        s=rng.randrange(65537)
        ga,gb,gc=g_bake(a,s),g_bake(b,s),g_bake(c,s)
        assert (ga-gb)+(gb-gc)==ga-gc
        wrong=(a*s+(1<<23))>>24
        if wrong!=ga and fused is None:
            fused={'depth':a,'stencil':s,'correct':ga,'fused_wrong':wrong}
        wrong_diff=g_bake(s32(a-b),s)
        if wrong_diff!=ga-gb and difference is None:
            difference={'a':a,'b':b,'stencil':s,'correct':ga-gb,'difference_wrong':wrong_diff}
    assert fused and difference
    return {'telescoping_cases':50000,'fused_rounding_counterexample':fused,
            'difference_form_counterexample':difference}


def nibble_div(n: int,d: int) -> int:
    if n<0 or d not in (9,11): raise ValueError('domain')
    q=r=0
    for k in range(36,-1,-4):
        digit=(n>>k)&15
        qd,r=divmod(16*r+digit,d)
        assert qd<16 and r<d
        q=(q<<4)|qd
    return q


def nibble_checks() -> dict:
    n=0
    for d in (9,11):
        for r in range(d):
            for digit in range(16):
                q,rn=divmod(r*16+digit,d)
                assert q<16 and rn<d; n+=1
    rng=random.Random(95009)
    for _ in range(20000):
        p=rng.randrange(1<<31)
        assert nibble_div(10*p+8,9)==(10*p+8)//9
        assert nibble_div(10*p,11)==10*p//11
    return {'table_entries_exhaustive':n,'lod_numerator_cases':20000}


def arena_checks() -> dict:
    depth,arenas=1089,2; iw=(depth-1).bit_length()
    old=(1<<iw)+130
    assert old==2178 and old>=depth*arenas
    old_last=(1<<iw)+1088; assert old_last==3136
    for d,a in ((1089,2),(17,3),(16,2),(81,4)):
        addresses=[ar*d+i for ar in range(a) for i in range(d)]
        assert len(set(addresses))==d*a and min(addresses)==0 and max(addresses)==d*a-1
    return {'source_derived_counterexample':{'DEPTH':1089,'ARENAS':2,'index':130,'old_address':old,'allocated_last':2177,'last_legal_logical_index_old_address':old_last},
            'correct_linear_layouts':[[1089,2],[17,3],[16,2],[81,4]],
            'rtl_simulation_performed':False}


def packed_replay_layout_checks() -> dict:
    """Address/port allocation model, not an RTL SRAM model or Quartus result."""
    groups, depth, width, copies = 4, 81, 115, 3
    rows = groups*depth
    slices = (width+19)//20
    blocks = copies*slices
    assert rows == 324 and rows <= 512 and slices == 6 and blocks == 18
    mem = [[None]*rows for _ in range(copies)]
    for group in range(groups):
        for index in range(depth):
            address = group*depth + index
            payload = (group << 100) | index
            for copy in mem:
                copy[address] = payload
    rng = random.Random(95010)
    probes = 0
    # Replay one sealed ping while filling the other. Each replica has one
    # independent read and the same one write; groups never alias.
    for _ in range(10000):
        ping = rng.randrange(2); view = rng.randrange(2)
        read_group = ping*2 + view
        write_group = (1-ping)*2 + rng.randrange(2)
        write_index = rng.randrange(depth)
        waddr = write_group*depth + write_index
        for replica in range(copies):
            index = rng.randrange(depth)
            raddr = read_group*depth + index
            assert raddr != waddr
            assert mem[replica][raddr] == ((read_group << 100) | index)
            probes += 1
    return {'rows': rows, 'useful_record_bits': width, 'read_replicas': copies,
            'proposed_geometry': '3 copies of 512x120 as six 512x20 slices each',
            'derived_m10k_blocks_not_a_measurement': blocks,
            'independent_read_address_probes': probes,
            'mixed_port_same_address_collision_excluded_by_group_identity': True,
            'rtl_simulation_or_memory_inference_performed': False}


def schedule_checks() -> dict:
    frame=100_000_000/60; reserve=frame*.8
    uncached=256*6144+120000
    whole=256*1089+120000
    sub=256*1296+120000
    assert uncached>frame
    assert whole*3<reserve
    assert sub*3>reserve
    assert whole*2*3>frame
    assert sub*2<reserve
    assert 120000*24>frame and 120000*12>reserve
    assert 120000*9<reserve
    assert 256*16*256<reserve
    return {'raw_frame_cycles':frame,'reserved_window':reserve,
            'uncached_combined_single_view':uncached,'whole_patch_II3':whole*3,
            'subpatch_II3':sub*3,'subpatch_Duo_II1':sub*2,
            'all_are_arithmetic_bounds_not_rtl_throughput':True}


def main() -> None:
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',type=Path)
    args=parser.parse_args()
    for name,fn in [('quarter_square_exhaustive',qs_exhaustive),('bilerp_exact',bilerp_checks),
                    ('fog_sign_and_rounding',fog_checks),('full_width_hybrid',hybrid_checks),
                    ('coefficient_products',coefficients_checks),('distributed_arithmetic',distributed_checks),
                    ('normal_width_reduction_square',normal_checks),('terrain_dda_and_separable_squares',dda_checks),
                    ('bake_rounding_and_telescoping',bake_round_checks),('lod_constant_division',nibble_checks),
                    ('arena_addressing',arena_checks),('workload_bounds',schedule_checks),
                    ('packed_three_read_replay_layout',packed_replay_layout_checks)]:
        check(name,fn)
    payload={'status':'pass','scope':'independent Python integer/source-address models; NOT RTL simulation or Quartus',
             'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
             'groups':RESULTS}
    text=json.dumps(payload,indent=2)
    if args.output: args.output.write_text(text+'\n',encoding='utf-8')
    print(text)

if __name__=='__main__': main()
