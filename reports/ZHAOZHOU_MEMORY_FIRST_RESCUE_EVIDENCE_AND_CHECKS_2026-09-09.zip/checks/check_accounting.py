#!/usr/bin/env python3
"""Small reference acceptance model, NOT a replacement repository census/parser.
It shows which bookkeeping states must prevent a whole-console closure claim.
Run: python check_accounting.py --output report.json
"""
from __future__ import annotations
import argparse, copy, hashlib, json
from pathlib import Path

class IncompleteBill(ValueError):
    pass


def validate(bill: dict, require_physical_closure: bool=False) -> dict:
    rows=bill['instances']; paths=[r['path'] for r in rows]
    if len(paths)!=len(set(paths)):
        raise ValueError('duplicate physical instance path')
    for i,a in enumerate(paths):
        for b in paths[i+1:]:
            if a.startswith(b+'.') or b.startswith(a+'.'):
                raise ValueError('inclusive parent/child cost overlap')
    implemented=set(); unresolved=[]; dsp=0
    for r in rows:
        if r.get('unit')!='physical_variable_precision_dsp_blocks':
            raise ValueError('wrong or missing DSP unit')
        if r.get('profile')!=r.get('evidence_profile'):
            raise IncompleteBill('parameter/configuration mismatch: '+r['path'])
        if not r.get('closure_identity_verified'):
            raise IncompleteBill('source identity not verified: '+r['path'])
        if r.get('evidence_kind') not in ('current_map','current_fit'):
            raise IncompleteBill('not a current measurement: '+r['path'])
        if r.get('dsp') is None:
            raise IncompleteBill('unknown DSP: '+r['path'])
        if not isinstance(r['dsp'],int) or r['dsp']<0:
            raise ValueError('invalid DSP count')
        implemented.update(r.get('implements',[]))
        for provider in r.get('providers',[]):
            if provider not in paths:
                raise IncompleteBill('missing physical service provider: '+provider)
        dsp+=r['dsp']
        if r.get('evidence_kind')!='current_fit' or r.get('alms') is None or r.get('m10k') is None:
            unresolved.append(r['path'])
        if require_physical_closure and r.get('gate_passed') is not True:
            raise IncompleteBill('physical gate not passed: '+r['path'])
    missing=set(bill.get('required_functions',[]))-implemented
    if missing: raise IncompleteBill('unpriced/unimplemented mandatory functions: '+','.join(sorted(missing)))
    if dsp>94: raise ValueError('DSP target exceeded')
    if require_physical_closure and unresolved:
        raise IncompleteBill('DSP subtotal does not establish fitted area/timing')
    return {'dsp_subtotal':dsp,'fitted_area_unresolved_paths':unresolved,
            'whole_console_closed':require_physical_closure and not unresolved}


def row(path: str,dsp: int,implements: list[str],**kwargs) -> dict:
    r={'path':path,'dsp':dsp,'unit':'physical_variable_precision_dsp_blocks',
       'profile':{'NCTX':8,'TOKW':14},'evidence_profile':{'NCTX':8,'TOKW':14},
       'closure_identity_verified':True,'evidence_kind':'current_fit',
       'alms':100,'m10k':1,'gate_passed':True,'implements':implements,'providers':[]}
    r.update(kwargs); return r


def main() -> None:
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',type=Path); args=parser.parse_args()
    results=[]
    def passed(name,fn):
        fn(); results.append({'name':name,'status':'pass'})
    def refused(name,bill,physical=False):
        try: validate(bill,physical)
        except (ValueError,IncompleteBill) as exc:
            results.append({'name':name,'status':'pass','rejection':str(exc)})
        else: raise AssertionError('expected rejection: '+name)
    base={'required_functions':['render','fog'],'instances':[row('console.renderer',6,['render']),row('console.fog',3,['fog'])]}
    passed('simple_complete_fixture',lambda: (_ for _ in ()).throw(AssertionError()) if validate(base,True)['dsp_subtotal']!=9 else None)
    b=copy.deepcopy(base); b['instances'].append(row('console.renderer.child',6,[])); refused('parent_plus_child',b)
    b=copy.deepcopy(base); b['instances'].append(copy.deepcopy(b['instances'][0])); refused('duplicate_path',b)
    b=copy.deepcopy(base); b['instances'][0]['dsp']=None; refused('unknown_not_zero',b)
    b=copy.deepcopy(base); b['instances'][0]['unit']='18x18_submultipliers'; refused('wrong_units',b)
    b=copy.deepcopy(base); b['instances'][0]['evidence_profile']['NCTX']=12; refused('parameter_mismatch',b)
    b=copy.deepcopy(base); b['instances'][0]['closure_identity_verified']=False; refused('clean_but_wrong_bytes',b)
    b=copy.deepcopy(base); b['instances'][0]['evidence_kind']='historical_fit'; refused('stale_measurement',b)
    b=copy.deepcopy(base); b['required_functions'].append('lighting'); refused('missing_required_lighting',b)
    b=copy.deepcopy(base); b['instances'][0]['providers']=['console.missing_root']; refused('missing_external_provider',b)
    b={'required_functions':['g0','g1'],'instances':[row('console.g0',33,['g0']),row('console.g1',33,['g1'])]}
    assert validate(b)['dsp_subtotal']==66; results.append({'name':'same_module_two_instances','status':'pass'})
    b={'required_functions':['a','b','multiply'],'instances':[row('console.a',0,['a'],providers=['console.bank']),row('console.b',0,['b'],providers=['console.bank']),row('console.bank',12,['multiply'])]}
    assert validate(b)['dsp_subtotal']==12; results.append({'name':'two_callers_one_provider','status':'pass'})
    b=copy.deepcopy(base); b['instances'][0].update(evidence_kind='current_map',alms=None,m10k=None)
    assert validate(b)['dsp_subtotal']==9 and not validate(b)['whole_console_closed']
    refused('map_is_not_fitted_closure',b,True)
    b=copy.deepcopy(base); b['instances'][0]['gate_passed']=False
    assert validate(b)['dsp_subtotal']==9
    refused('measured_failed_policy_stays_failed',b,True)
    b=copy.deepcopy(base); b['instances'][0]['dsp']=92; refused('hard_target_is94',b)
    # Dirty git does not invalidate a verified immutable byte/config identity.
    b=copy.deepcopy(base); b['instances'][0]['git_clean']=False
    assert validate(b,True)['whole_console_closed']; results.append({'name':'immutable_dirty_snapshot_is_identifiable','status':'pass'})
    # Label selection is upstream: the identified selected measurement remains usable.
    b=copy.deepcopy(base); b['instances'][0]['measurement_id']='rcp@g8-t14'; b['instances'][0]['dsp']=3
    assert validate(b)['dsp_subtotal']==6; results.append({'name':'selected_label_not_extra_silicon','status':'pass'})
    payload={'status':'pass','scope':'small acceptance fixtures; not the live repository census',
             'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'checks':results}
    text=json.dumps(payload,indent=2)
    if args.output: args.output.write_text(text+'\n',encoding='utf-8')
    print(text)

if __name__=='__main__': main()
