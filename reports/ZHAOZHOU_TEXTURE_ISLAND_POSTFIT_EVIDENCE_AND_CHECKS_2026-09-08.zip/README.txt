ZHAOZHOU: POST-FIT TEXTURE ISLAND ARCHITECTURE BRIEF
2026-09-08

Start with ZHAOZHOU_TEXTURE_ISLAND_POSTFIT_ARCHITECTURE_2026-09-08.txt.
Section 0 gives the decision; section 11 gives implementation packets;
section 12 is the paste-ready owner instruction; section 14 reconciles
live agent commits so already-completed repairs are not restarted.

Contents
--------
The TXT brief; immutable repository/vendor references in source_manifest.json;
transcribed first-V3 physical facts in MEASURED_BASELINE.json; six independent
Python model checks and their actual successful run log; SHA256SUMS.txt.

This bundle does NOT contain the entire repository or full raw Quartus reports.
The source manifest is a reference index. Large full-detail setup/hold reports
were not independently readable through the connector; compact summaries and
all-corner STA were read. Their missing detailed endpoints are an explicit
follow-through item, not a reason to dismiss hold violations.

Run checks
----------
Requires Python 3.10 or newer, standard library only:

  python independent_checks.py

The program exits nonzero on any failed check. It needs no network and changes
no repository files. The included log was regenerated from the shipped source
while packaging. On a system with sha256sum, bundle integrity can be checked:

  sha256sum -c SHA256SUMS.txt

The checks prove only the finite algebra/model properties they describe.
They do NOT execute the repository RTL, infer RAM, run Quartus, prove reset
reachability, or establish timing/throughput on hardware. The 300/300 zero-work
RTL result and other project gates are repository-reported results, not local
runs by this review.

Key corrections
---------------
The new overflow event is accept&&full with accept=valid&&!full: always false.
The zero-work stall was a test-environment confound and was retracted.
The full metadata join is 40 bits, not the agent candidate's 21-bit subset.
Palette statistics can be separated from the already-registered verdict.
82.41 MHz is the first-corner headline; another slow corner gives 81.58 and
multicorner hold slack is -4.346 ns. No product timing closure is claimed.
Freeze the compiled source/configuration snapshot, not unrelated live work.
