#!/usr/bin/env python3
"""Independent finite/abstract checks for the September 8 post-fit brief.

These are NOT repository RTL simulation, FPGA timing analysis, or a proof of
reachability in the repository. Each model names the claim it actually checks.
Python 3.10+; standard library only. No files or network services are required.
"""
from __future__ import annotations

from collections import deque
from dataclasses import dataclass
import random
from typing import Optional

MASK32 = (1 << 32) - 1


def check(condition: bool, message: str) -> None:
    if not condition:
        raise AssertionError(message)


def overflow_litmus() -> None:
    # Exact Boolean substitution of the new source predicate, not a fit.
    for valid in (False, True):
        for full in (False, True):
            ready = not full
            accept = valid and ready
            check(not (accept and full), 'original overflow predicate became true')
    mutant_fires = True and True  # deliberately change ready to True at full
    check(mutant_fires, 'ready-always-high mutant did not demonstrate the distinction')
    # A realistic shared-predicate mutant accepts a fifth word but the
    # detector remains false: changing >=4 to >4 changes BOTH users.
    occ = 4
    wrong_full = occ > 4
    wrong_accept = not wrong_full
    check(wrong_accept and not (wrong_accept and wrong_full),
          'off-by-one-full mutant did not demonstrate detector blindness')
    check(occ + int(wrong_accept) > 4, 'independent range check missed fifth word')
    # A separate occupancy-range detector is not a Boolean contradiction.
    ranges = [(occ, occ > 4) for occ in range(8)]
    check([x for x, hit in ranges if hit] == [5, 6, 7], 'range detector malformed')
    print('C1 PASS: 4 Boolean cases; accept&&full is identically false. '
          'Off-by-one FULL accepts a fifth word without firing the old detector; independent range check catches it.')


def environment_litmus() -> None:
    # Abstract ordered completion: earlier work needs a response never provided.
    pending = deque([(1000 + i, False) for i in range(24)] +
                    [(i, True) for i in range(40)])
    retired = []
    while pending and pending[0][1]:
        retired.append(pending.popleft()[0])
    check(not retired, 'ordered machine skipped an incomplete older owner')
    # The zero-work records are complete. They are not responsible for the block.
    check(all(done for tag, done in list(pending)[24:]), 'zero work was not complete')
    clean = deque((i, True) for i in range(300))
    check([clean.popleft()[0] for _ in range(300)] == list(range(300)),
          'clean zero-work model did not drain')
    # Mutant: skip the oldest incomplete owner. This falsely appears to recover.
    mutant = [tag for tag, done in pending if done]
    check(mutant and mutant[0] == 0, 'bad skip-head model not distinguishable')
    print('C2 PASS: an unanswered earlier request blocks later complete records in a '
          'correct ordered machine. Clean reset removes that confound; this is NOT an RTL reproduction.')


@dataclass(frozen=True)
class Verdict:
    valid: bool = False
    stale: bool = False
    resident: bool = False

    def increments(self) -> tuple[int, int, int]:
        return (int(self.valid), int(self.valid and self.stale),
                int(self.valid and not self.stale and not self.resident))


def add_counts(a: tuple[int, int, int], b: tuple[int, int, int]) -> tuple[int, int, int]:
    return tuple((x + y) & MASK32 for x, y in zip(a, b))  # type: ignore[return-value]


def palette_events() -> None:
    # st=(generation mismatch)||accepted same-slot BEGIN.
    # Resident snapshot excludes same-slot BEGIN. Original cold uses !old res,
    # but is only counted when !st, making !snapshot res equivalent in that arm.
    cases = 0
    for valid in (False, True):
        for mismatch in (False, True):
            for old_resident in (False, True):
                for begin in (False, True):
                    stale = mismatch or begin
                    verdict = Verdict(valid, stale, old_resident and not begin)
                    old = (int(valid), int(valid and stale),
                           int(valid and not stale and not old_resident))
                    check(verdict.increments() == old, 'palette event partition changed')
                    cases += 1
    rng = random.Random(0x50414C)
    original = (MASK32 - 10, MASK32 - 10, MASK32 - 10)
    delayed = original
    pending = Verdict()
    for t in range(100000):
        reset = rng.randrange(997) == 0
        event = Verdict(bool(rng.getrandbits(1)), bool(rng.getrandbits(1)),
                        bool(rng.getrandbits(1)))
        old_original = original
        if reset:
            original = delayed = (0, 0, 0)
            pending = Verdict()
        else:
            original = add_counts(original, event.increments())
            delayed = add_counts(delayed, pending.increments())
            check(delayed == old_original, f'delayed count not one cycle behind at {t}')
            pending = event
        check(add_counts(delayed, pending.increments()) == original,
              f'pending event conservation failed at {t}')
    delayed = add_counts(delayed, pending.increments())
    check(delayed == original, 'one-cycle drain did not reconcile counts')
    # A valid OLD lookup followed by reload must keep its accepted verdict;
    # recomputing against the new palette state changes classification.
    captured = Verdict(True, False, True)
    wrong_recheck = Verdict(True, True, False)
    check(captured.increments() != wrong_recheck.increments(),
          'live-generation-recheck mutant escaped')
    print(f'C3 PASS: {cases} verdict cases; 100000 event/reset/counter-wrap cycles. '
          'Delayed counters equal the old counters after one drain cycle. Live-state recheck mutant detected.')


@dataclass(frozen=True)
class Packet:
    ident: int
    payload: int
    meta21: int
    pal_slot: int
    pal_gen: int


def packet(n: int) -> Packet:
    return Packet(n, (n * 0xD6E8FEB86659FD93) & ((1 << 64) - 1),
                  (n * 0x1327 + 9) & ((1 << 21) - 1), (n // 3) & 3,
                  (n * 31 + n // 5 + 7) & 255)


def join_model(seed: int, bad_credit: bool = False) -> tuple[int, int, int, bool]:
    rng = random.Random(seed)
    depth, latency = 4, 2
    q: deque[Packet] = deque()
    flight: deque[tuple[int, Packet]] = deque()
    expected: deque[Packet] = deque()
    accepted = emitted = peak = 0
    overflow = False
    previous_stall: Optional[Packet] = None
    for t in range(10000):
        # Deterministic stall windows ensure launched reads meet abrupt stalls.
        ready = (t % 97 >= 11) and bool(rng.getrandbits(1))
        if t >= 9900:
            ready = True
        if previous_stall is not None:
            check(q and q[0] == previous_stall, 'offered output changed while stalled')
        if q and ready:
            got = q.popleft()
            check(expected and got == expected.popleft(), 'join changed packet or order')
            emitted += 1
        while flight and flight[0][0] == t:
            q.append(flight.popleft()[1])
        owned = len(q) + len(flight)
        free_basis = len(q) if bad_credit else owned
        if t < 9900 and free_basis < depth and rng.random() < 0.9:
            p = packet(accepted)
            flight.append((t + latency, p))
            expected.append(p)
            accepted += 1
        peak = max(peak, len(q) + len(flight))
        if len(q) + len(flight) > depth:
            overflow = True
            if bad_credit:
                return accepted, emitted, peak, overflow
            raise AssertionError('credited join overflow')
        previous_stall = q[0] if q and not ready else None
    check(not q and not flight and not expected, 'join failed to drain')
    check(accepted == emitted, 'join lost work')
    return accepted, emitted, peak, overflow


def metadata_join() -> None:
    total = 0
    for seed in range(32):
        a, b, peak, bad = join_model(seed)
        check(a == b and peak <= 4 and not bad, 'good join model failed')
        total += a
    check(join_model(0, True)[3], 'ignore-in-flight-credit mutant escaped')
    a, b = packet(1), packet(2)
    # Carrying 21 bits alone leaves palette identity subject to a later read.
    wrong = Packet(a.ident, a.payload, a.meta21, b.pal_slot, b.pal_gen)
    check(wrong != a, 'palette association mutant not distinguishable')
    print(f'C4 PASS: 32 x 10000 credited-join cycles, {total} packets, capacity 4. '
          'In-flight-credit and wrong-palette-association mutants detected. Abstract protocol, not inferred RAM.')


def prep_model(bad_reservation: bool = False) -> bool:
    # Abstract PREPARING/EXECUTING reservations. No reciprocal arithmetic.
    occupied: dict[int, int] = {}
    flight: deque[tuple[int, int, int]] = deque()
    release: deque[tuple[int, int, int]] = deque()
    for t in range(1000):
        while release and release[0][0] == t:
            _, slot, ident = release.popleft()
            check(occupied.get(slot) == ident, 'wrong preparation owner released')
            del occupied[slot]
        while flight and flight[0][0] == t:
            _, slot, ident = flight.popleft()
            if bad_reservation:
                if slot in occupied:
                    return True
                occupied[slot] = ident
            else:
                check(occupied.get(slot) == ident, 'prepared context lost reservation')
            release.append((t + 16, slot, ident))
        free = next((i for i in range(8) if i not in occupied), None)
        if free is not None:
            if not bad_reservation:
                occupied[free] = t
            flight.append((t + 3, free, t))
        check(len(occupied) <= 8, 'context capacity exceeded')
    return False


def preparation() -> None:
    check(not prep_model(), 'correct reserve-at-admission failed')
    check(prep_model(True), 'reserve-only-at-publication mutant escaped')
    print('C5 PASS: 1000 preparation-reservation cycles, 8 contexts. '
          'Deferred-reservation alias detected. No claim about actual RCP throughput or arithmetic.')


def completion_selection_litmus() -> None:
    # State-level witness for an unlocked priority selector, NOT a proof that
    # this state is reachable from reset in the repository.
    done_before, done_after = {5}, {0, 5}
    offered, following = min(done_before), min(done_after)
    check(offered != following, 'priority-preemption witness missing')
    held = offered
    check(held == offered, 'holding record not stable')
    print('C6 PASS: an unlocked DONE priority scan can change the offered token '
          'during a stall. State-level witness only; RTL reachability and interface obligation require separate tests.')


def main() -> None:
    overflow_litmus()
    environment_litmus()
    palette_events()
    metadata_join()
    preparation()
    completion_selection_litmus()
    print('ALL INDEPENDENT CHECKS PASS. No repository RTL, Quartus, or board run was performed.')


if __name__ == '__main__':
    main()
