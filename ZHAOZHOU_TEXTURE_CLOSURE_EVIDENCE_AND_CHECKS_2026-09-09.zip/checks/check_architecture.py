#!/usr/bin/env python3
"""Independent finite/arithmetic models for the texture-closure proposal.
Not Verilator, not an RTL equivalence proof, and not a Quartus measurement.
Run with Python 3.10+; outputs a deterministic JSON receipt.
"""
from __future__ import annotations
import argparse
import itertools
import json
import random
import re
from collections import deque
from pathlib import Path

MASK14 = (1 << 14) - 1
MASK64 = (1 << 64) - 1
LO32, HI32 = -(1 << 31), (1 << 31) - 1
SEED = 20260909


def signed(v: int, width: int) -> int:
    v &= (1 << width) - 1
    return v - (1 << width) if v >> (width - 1) else v


def live_reference(head: int, used: int, ticket: int) -> bool:
    return ((ticket - head) & MASK14) < used


def live_factored(head: int, used: int, ticket: int) -> bool:
    """Exact only for the specified 64-owner / 8-generation-bit profile."""
    assert 0 <= used <= 64
    e, g = head & 63, (head >> 6) & 255
    s, h = ticket & 63, (ticket >> 6) & 255
    delta = (s - e) & 63
    expected = (g + int(s < e)) & 255
    return delta < used and h == expected


def live_bounds(head: int, used: int, ticket: int) -> bool:
    """No per-query subtraction: at most two contiguous slot intervals."""
    assert 0 <= used <= 64
    e, g = head & 63, head >> 6
    a = (e + used) & 63
    s, h = ticket & 63, ticket >> 6
    if used == 0:
        return False
    if a > e:
        return e <= s < a and h == g
    return ((s >= e and h == g) or (s < a and h == ((g + 1) & 255)))


def check_window(rng: random.Random) -> dict:
    count = 0
    # All head slots, occupancies, query slots, and both adjacent/bad generations.
    # Generation translation is separately randomized across the complete domain.
    for g in (0, 255):
        for e in range(64):
            head = (g << 6) | e
            for used in range(65):
                for h in ((g-1)&255, g, (g+1)&255, (g+2)&255):
                    for s in range(64):
                        t = (h << 6) | s
                        expected = live_reference(head, used, t)
                        assert live_factored(head, used, t) == expected
                        assert live_bounds(head, used, t) == expected
                        count += 1
    for _ in range(100_000):
        head, used, t = rng.randrange(16384), rng.randrange(65), rng.randrange(16384)
        assert live_reference(head, used, t) == live_factored(head, used, t) == live_bounds(head, used, t)
        count += 1
    # Mutants: slot-only identity; full/empty alias; public {slot,gen} subtraction.
    assert live_reference(64, 1, 128) != (((128 & 63) - (64 & 63)) & 63 < 1)
    assert live_bounds(64, 64, 64) and not live_bounds(64, 0, 64)
    owner_public = lambda t: ((t & 63) << 8) | (t >> 6)
    assert live_reference(127, 2, 128) != (((owner_public(128)-owner_public(127)) & MASK14) < 2)
    # Identity must be valid at BOTH snapshot and claim.
    assert not live_reference(64, 1, 65) and live_reference(64, 2, 65)
    assert live_reference(64, 1, 64) and not live_reference(65, 0, 64)
    return {"comparisons": count, "mutants_rejected": 3, "snapshot_current_counterexamples": 2}


def bits_from_phases(phases: tuple[int, ...]) -> tuple[int, int, int]:
    issued = sum((p != 0) << i for i, p in enumerate(phases))
    claimed = sum((p >= 2) << i for i, p in enumerate(phases))
    committed = sum((p == 3) << i for i, p in enumerate(phases))
    return issued, claimed, committed


def check_owner_encoding(rng: random.Random) -> dict:
    decisions = transitions = 0
    # Five legal states per source: not required; required and phase0/1/2/3.
    for states in itertools.product(range(5), repeat=4):
        req = sum((x != 0) << i for i, x in enumerate(states))
        phases = tuple(max(0, x-1) for x in states)
        iss, clm, cmt = bits_from_phases(phases)
        assert not (cmt & ~clm) and not (clm & ~iss) and not (iss & ~req)
        assert ((cmt & req) == req) == all(not (req >> i & 1) or phases[i] == 3 for i in range(4))
        for i in range(4):
            for identity_ok, in_range, forwarded in itertools.product((False, True), repeat=3):
                bit = 1 << i
                old = identity_ok and in_range and bool(req & bit) and bool(iss & bit) and not bool((clm|cmt)&bit) and not forwarded
                new = identity_ok and in_range and bool(req & bit) and phases[i] == 1 and not forwarded
                assert old == new
                decisions += 1
        for phase in range(4):
            cbi, fcl, fdn = phase != 0, phase >= 2, phase == 3
            assert (cbi and not fcl and not fdn) == (phase == 1)
            decisions += 1
    # Independent sticky-mask and encoded-state updates, admission precedence included.
    for _ in range(50_000):
        phases = tuple(rng.randrange(4) for _ in range(4))
        req = 15
        iss, clm, cmt = bits_from_phases(phases)
        ni, nc, nm = iss, clm, cmt
        out = list(phases)
        for j, p in enumerate(phases):
            advance = rng.choice((False, True))
            if advance and p == 0: ni |= 1 << j
            elif advance and p == 1: nc |= 1 << j
            elif advance and p == 2: nm |= 1 << j
            if advance and p < 3: out[j] = p + 1
        if rng.randrange(8) == 0:  # a new admission resets all source state last
            req = rng.randrange(16)
            ni = nc = nm = 0
            out = [0] * 4
        assert (ni, nc, nm) == bits_from_phases(tuple(out))
        transitions += 1
    # A final terminal after reservation alone must NOT be accepted.
    crs, final_phase = True, 0
    assert crs and not (final_phase == 1)
    # Same-owner T/A publication emits ONE ticket, different owners may emit two.
    assert len({(13, 7), (13, 7)}) == 1
    assert len({(13, 7), (13, 8)}) == 2
    # The encoded form cannot represent committed-without-claimed at all.
    assert all(not ((p == 3) and not (p >= 2)) for p in range(4))
    return {"decision_cases": decisions, "transition_cases": transitions,
            "logical_state_bits_saved_at_64": 320, "is_mapped_register_saving": False}


def check_palette(rng: random.Random) -> dict:
    sequences = events = 0
    for _ in range(200):
        seen = [False] * 256
        words = [0] * 8
        groups = [False] * 8
        order = list(range(256))
        rng.shuffle(order)
        order += [rng.randrange(256) for _ in range(100)]
        for idx in order:
            seen[idx] = True
            g, b = idx >> 5, idx & 31
            words[g] |= 1 << b
            groups[g] = words[g] == 0xffffffff
            assert all(seen) == all(groups)
            events += 1
        assert all(groups)
        sequences += 1
    # 256 writes are NOT 256 distinct entries.
    seq = list(range(255)) + [254]
    assert len(seq) == 256 and len(set(seq)) == 255
    # Last WRITE immediately followed by END sees the updated group bit.
    words = [0xffffffff] * 8
    words[7] &= ~(1 << 31)
    flags = [w == 0xffffffff for w in words]
    assert not all(flags)
    words[7] |= 1 << 31
    flags[7] = words[7] == 0xffffffff
    assert all(flags)
    # Accepted BEGIN invalidates; rejected same-generation BEGIN does not.
    for valid, begin, same_slot, gen_equal in itertools.product((False, True), repeat=4):
        accepted = valid and begin and not gen_equal
        forwarded = accepted and same_slot
        if valid and begin and same_slot and gen_equal:
            assert not forwarded
    return {"write_sequences": sequences, "checked_writes": events, "duplicate_write_mutant_rejected": True}


def rescale_old(n: int, m: int, k: int) -> tuple[int, bool]:
    p = signed(n, 32) * (m & 0xffffff)
    sh = (32 - (k & 63)) & 63
    rnd = signed(1 << ((sh - 1) & 63), 64)
    value = signed(p + rnd, 64) >> sh
    return max(LO32, min(HI32, value)), not LO32 <= value <= HI32


def rescale_new(n: int, m: int, k: int) -> tuple[int, bool]:
    p = signed(n, 32) * (m & 0xffffff)
    sh = (32 - (k & 63)) & 63
    assert -(1 << 55) < p < (1 << 55)
    if sh == 0:  # preserve the existing generic service's 64-bit wrap law
        return (LO32, True) if p >= 0 else (HI32, True)
    if sh >= 56:
        return 0, False
    value = (p >> sh) + ((p >> (sh-1)) & 1)
    return max(LO32, min(HI32, value)), not LO32 <= value <= HI32


def check_rescale(rng: random.Random) -> dict:
    nvals = [LO32, LO32+1, -65536, -1, 0, 1, 65535, HI32-1, HI32]
    mvals = [0, 1, 127, 128, 0x7fffff, 0x800000, 0xffffff]
    count = 0
    for n, m, k in itertools.product(nvals, mvals, range(64)):
        assert rescale_old(n,m,k) == rescale_new(n,m,k)
        count += 1
    for _ in range(200_000):
        n, m, k = rng.randrange(1 << 32), rng.randrange(1 << 24), rng.randrange(64)
        assert rescale_old(n,m,k) == rescale_new(n,m,k)
        count += 1
    # Naively interpreting shift0 as an ordinary unrounded product is wrong.
    assert rescale_old(1,1,32) == (LO32, True)
    assert rescale_old(1,1,32) != (1,False)
    return {"full_6bit_k_cases": count, "naive_narrowing_mutant_rejected": True,
            "mapping_gain_measured": False}


def check_quarter_square(rng: random.Random) -> dict:
    q = lambda x: (x*x) // 4
    count = 0
    for a in range(256):
        for b in range(256):
            raw = q(a+b) - q(abs(a-b))
            assert raw == a*b
            assert min(255, (raw+128) >> 8) == min(255,(a*b+128)>>8)
            count += 1
    def rommul(a: int, b: int) -> int:
        sgn = -1 if a < 0 else 1
        a = abs(a)
        return sgn * (q(a+b)-q(abs(a-b)))
    # Full precision bilinear reconstruction, single FINAL rounding only.
    bcount = 0
    for _ in range(100_000):
        t00,t10,t01,t11,fu,fv = [rng.randrange(256) for _ in range(6)]
        a = (t00<<8) + (t10-t00)*fu
        b = (t01<<8) + (t11-t01)*fu
        ref = ((a<<8)+(b-a)*fv+32768)>>16
        aa = (t00<<8)+rommul(t10-t00,fu)
        bb = (t01<<8)+rommul(t11-t01,fu)
        dv = bb-aa
        mag = abs(dv)
        prod = rommul(mag&255,fv) + (rommul(mag>>8,fv)<<8)
        if dv < 0: prod = -prod
        got = ((aa<<8)+prod+32768)>>16
        assert got == ref
        bcount += 1
    assert q(255+255) == 65025  # 16 bits; table needs the 9-bit sum address
    return {"byte_product_cases": count, "bilinear_cases": bcount, "rom_bits_per_lane": 512*16}


def check_cache_reservations(rng: random.Random) -> dict:
    cap = 4
    pipe: deque[int | None] = deque([None, None])
    rsp: deque[int] = deque()
    todo: deque[int] = deque()
    accepted = delivered = next_id = 0
    resv = 0
    cold = 0
    cycles = 80_000
    for _ in range(cycles):
        if len(todo) < 4 and rng.random() < .60:
            todo.append(next_id); next_id += 1; accepted += 1
        pop = bool(rsp) and rng.random() < .65
        tail = pipe[-1]
        miss = cold == 0 and tail is not None and rng.random() < .08
        issue = cold == 0 and not miss and bool(todo) and resv < cap
        # todo contains unissued records only; miss requeues exact older identities.
        if pop:
            got = rsp.popleft()
            assert got == delivered
            delivered += 1
        if cold:
            cold -= 1
            assert all(x is None for x in pipe)
            issue = False
        if miss:
            killed = [x for x in reversed(pipe) if x is not None]
            refund = len(killed)
            for x in reversed(killed): todo.appendleft(x)
            pipe = deque([None, None])
            resv -= refund
            cold = 3  # additional cold miss stages do not lengthen the hit pipeline
        else:
            retired = pipe.pop()
            if retired is not None: rsp.append(retired)
            pipe.appendleft(todo.popleft() if issue else None)
            resv += int(issue)
        resv -= int(pop)
        assert resv == len(rsp)+sum(x is not None for x in pipe)
        assert 0 <= resv <= cap
        assert accepted-delivered == len(todo)+len(rsp)+sum(x is not None for x in pipe)
    # Positive-control arithmetic: failing to refund leaves a leak immediately.
    before, fifo, in_flight = 4, 2, 2
    assert before-in_flight == fifo
    assert before != fifo
    return {"cycles": cycles, "admitted": accepted, "delivered": delivered,
            "quiescent_drain_not_required_for_conservation": True, "miss_refund_mutant_rejected": True}


def check_pull_combiner() -> dict:
    """Storage/lifetime obligations for read-late jobs, not recipe RTL."""
    rows = {i: (i*13, i*17, i*19, i*23) for i in range(64)}
    jobs = deque()
    final = deque()
    reserved = set()
    issued = set()
    live = set(range(64))
    reads = 0
    for i in range(64):
        reserved.add(i)
        assert i not in issued  # merely reserving/reading is not actual engine issue
        issued.add(i)
        jobs.append((i, i % 3 + 1))
    original = dict(rows)
    while jobs:
        i, remaining = jobs.popleft()
        assert i in issued and i in live
        assert rows[i] == original[i]
        reads += 1
        if remaining > 1: jobs.append((i, remaining-1))
        else: final.append(i)
    assert live == set(range(64))  # completion and prefetch do not free owners
    # Final results may arrive out of order; the boundary releases admission order.
    completed = set(final)
    for i in range(64):
        assert i in completed
        live.remove(i)
    assert not live
    # Explicit RAM access feasibility: one per-phase read, independent source writes.
    ports = {"sample0": (1,1), "sample1": (1,1), "sample2": (1,1), "aux": (1,1), "material": (1,1)}
    assert all(r+w <= 2 for r,w in ports.values())
    return {"owners": 64, "phase_reads": reads, "wide_cq_logical_bits_removed": 4*(14+4*40),
            "per_context_immutable_payload_bits_avoided": 8*110, "these_are_not_fitted_register_deltas": True}


def check_worker_schedule() -> dict:
    """Two phase-specific workers: capacity/schedule model, not reciprocal RTL."""
    n = 12_000
    latency = 9  # illustrative issue-to-writeback latency, not a hardware claim
    contexts = 32
    free = deque(range(contexts))
    new = deque(); mwcont = deque(); mxready = deque()
    inflight = []
    admitted = completed = mw = mx = 0
    first_done = None
    cycle = 0
    while completed < n:
        arriving = [x for x in inflight if x[0] == cycle]
        inflight = [x for x in inflight if x[0] != cycle]
        for _, ctx, phase in arriving:
            if phase == 0: mxready.append((ctx,1))
            elif phase == 1: mwcont.append((ctx,2))
            elif phase == 2: mxready.append((ctx,3))
            else:
                completed += 1; free.append(ctx)
                if first_done is None: first_done = cycle
        if admitted < n and free:
            new.append((free.popleft(),0)); admitted += 1
        job = mwcont.popleft() if mwcont else (new.popleft() if new else None)
        if job is not None:
            mw += 1; inflight.append((cycle+latency,*job))
        if mxready:
            job = mxready.popleft(); mx += 1
            inflight.append((cycle+latency,*job))
        assert admitted-completed == len(new)+len(mwcont)+len(mxready)+len(inflight)
        assert admitted-completed <= contexts
        cycle += 1
        assert cycle < 100_000
    assert mw == mx == n*2
    return {"modeled_jobs": n, "illustrative_worker_latency": latency, "contexts": contexts,
            "cycles": cycle, "cycles_per_job_including_fill_drain": cycle/n,
            "MW_launches": mw, "MX_launches": mx,
            "is_RTL_performance_evidence": False}


def check_budget_and_audit() -> dict:
    alloc = {"completion_complex":1900,"paired_uv":800,"rcp":1000,"planner":700,
             "cache":950,"response_palette_filter":800,"aux":500,"remaining_glue_and_descriptors":850}
    assert sum(alloc.values()) == 7500
    # Never assume small 32x32xdepth storage fits one TDP block: width <=20 there.
    assert (124+39)//40 == 4  # one-write/one-read SDP pooled payload
    assert (124+19)//20 == 7  # two arbitrary read/write ports would require seven slices
    # Baseline 49; replace inclusive old RCP allocation only using an actual delta.
    conditional_mem = 49 + 7 + 2 + 4
    assert conditional_mem == 62
    assert conditional_mem + 4 > 64  # cannot also add the response pool without reclaiming RAM
    # Whitespace-sensitive search would falsely declare functional arrays absent.
    text = 'clm_q [i] <= clm_n_c [i];\ncbi_q [i] <= cbi_n_c [i];\nfcl_q [i] <= fcl_n_c [i];'
    for name in ('clm_q','cbi_q','fcl_q'):
        assert not re.search(r'\b'+name+r'\[', text)
        assert re.search(r'\b'+name+r'\s*\[', text)
    nf, slots = 541_640, 1_333_333
    perfect_uncached = 4*nf
    assert perfect_uncached > slots
    return {"ALM_allocations_NOT_predictions": alloc, "sum": sum(alloc.values()),
            "conditional_M10K_without_response_pool": conditional_mem,
            "uncached_four_launch_lower_bound": perfect_uncached,
            "miss_rate_limit_at_4_38_clocks_per_miss": slots/(4.38*nf),
            "whitespace_false_absence_mutant_rejected": True}


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument('--output', type=Path, default=Path('architecture_checks.json'))
    args = ap.parse_args()
    rng = random.Random(SEED)
    funcs = [check_window, check_owner_encoding, check_palette, check_rescale,
             check_quarter_square, check_cache_reservations]
    results = {f.__name__: f(rng) for f in funcs}
    for f in (check_pull_combiner, check_worker_schedule, check_budget_and_audit):
        results[f.__name__] = f()
    receipt = {"seed": SEED, "kind": "independent Python models, NOT RTL or fitter evidence",
               "all_passed": True, "groups": len(results), "results": results}
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(receipt,indent=2)+'\n')
    print(json.dumps(receipt,indent=2))
    return 0

if __name__ == '__main__':
    raise SystemExit(main())
