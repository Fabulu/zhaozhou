ZHAOZHOU TEXTURE ISLAND CLOSURE -- LOCAL CONTROL, RESIDENT DATA

START WITH BRIEF.txt. Section22 is the direct agent handoff; sections19-21
specify implementation order, fit custody and exit criteria.

This package is a proposed texture-island architecture after Gate2. It does
not replace the separate whole-console memory-first rescue. It is not a
prebuilt RTL patch, a tested hardware implementation, or a guarantee of fit.

FILES
  BRIEF.txt                         Comprehensive cited architecture.
  checks/check_architecture.py       Standalone deterministic Python models.
  evidence/architecture_checks.json  Results from those models, NOT RTL tests.
  evidence/check_run.log             Recorded model output.
  evidence/source_manifest.json      Immutable source URLs and inspection scope.
  evidence/resource_allocation.json  Target portfolio; NOT measured savings.
  evidence/memory_port_contracts.json Proposed port/mode ownership.
  evidence/acceptance_receipt_template.json  Blank candidate checkpoint template.
  evidence/freshness.json            Inspected pins and late observation.
  evidence/reproducibility.json      Two independent local runs compared.
  evidence/document_qa.json          Mechanical document checks.
  SHA256SUMS.txt                     Integrity of the delivered package.

RUN
  Python3.10 or newer; no third-party dependencies and no network required.
  python checks/check_architecture.py --output evidence/architecture_checks.json

The script writes only its requested output. It does not modify a repository,
start synthesis, contact the working agent, or run in the background.

MEASUREMENT DISCIPLINE
  Logical bits != mapped registers != fitted registers != fitted ALMs.
  Mapped memory bits != physical M10K allocation.
  Resource allocation != measured candidate result.
  Arithmetic/model agreement != RTL equivalence or frame-rate evidence.

Before implementation, refresh the working branch and confirm that the
structures described in the brief still exist. Preserve Gate2 as a reference,
not as an excuse to freeze all future development. Do not count old and new
implementations simultaneously in a shipping resource bill.
