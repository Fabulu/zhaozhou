// zhao_mem_guard.sv — region/ownership checker between EVERY fabric VRAM
// client and the memory system (plan W2.5). Law: spec/memory_rules.md §5;
// contract design/contracts/MEM.GUARD.md.
//
// Phase-2 region map (mode-independent — both slots are sized for the
// LARGEST canvas, so a mode switch never moves a slot):
//   FB slot 0 : [0x0000_0000, 0x0003_C000)   245,760 B  (DRAM bank 0)
//   FB slot 1 : [0x0200_0000, 0x0203_C000)   245,760 B  (DRAM bank 1 —
//               the W2.7 bank split; see zhao_pkg ZHAO_FB_SLOT1_BASE)
//   everything else: unmapped — violation by construction.
//   ENFORCED-BY: tests/formal/mem_guard_no_escape.sby
//
// Phase-3 extensions, each a window opened WITH the block that needed it:
//   GEOM.ASSET_POOL   : [0x06A0_0000, 0x0800_0000)  22 MiB, ENGINE1, READ-only
//   TERRAIN.PAGE_POOL : [0x0400_0000, 0x054E_0000)  20.875 MiB,
//                       TERRAIN.BUILD, WRITE (pages in) and READ (F sheets
//                       out) -- ONE window, TWO arms, TWO theorems
//                       (rulings T2 / T3 / T4, §5b)
//
// Ownership law:
//   * SCANOUT owns BOTH slots, READ-ONLY (a write is a violation).
//   * BLIT_DMA owns exactly the CMD-granted slot window
//     [slot_base, slot_base + blit_span) — blit_span = canvas_bytes(mode),
//     written by CMD.SCHEDULER at frame grant. Writes only (Phase-2 blit
//     never reads VRAM: a read is a violation by construction).
//     map_valid=0 (no grant this frame) => deny-all.
//     ENFORCED-BY: tests/formal/mem_guard_no_escape.sby
//   * ENGINE0/ENGINE1/DEBUG own nothing in Phase 2 (reserved ports) —
//     violation by construction. (ENGINE0 and ENGINE1 acquired windows in
//     Phase 3; DEBUG still owns nothing, and neither does the unspent
//     client 5.)
//     ENFORCED-BY: tests/formal/mem_guard_no_escape.sby
//   * TERRAIN.BUILD owns TERRAIN.PAGE_POOL IN BOTH DIRECTIONS, and no other
//     client reaches it in either. Spatially the WHOLE pool, not the LOADING
//     slot T2 eventually wants — the difference is spelled out at
//     `terrain_ok` below rather than left for a reader to discover.
//     ENFORCED-BY: tests/formal/mem_guard_no_escape.sby
//
// Request law: len 1..64 bytes; byte_enable must be the FULL contiguous mask
// over [addr, addr+len) (Phase-2 clients issue whole spans; partial-word
// tails are a Phase-3 map concern). Span arithmetic is done at 32 bits so
// addr+len can never wrap past the map.
//
// Verdict: fixed 1 cycle (registered rsp). A passing request is forwarded to
// the arbiter port and held there until the arbiter grants it (ready/valid
// end-to-end — the guard never drops a legal request, never invents one).
// A denied request is ANSWERED (guard_violation pulse + count + latched
// trace record, charter §29-17 lane) and NOTHING is forwarded — the formal
// property mem_guard_no_escape proves no violating request ever reaches the
// arbiter port and no partial forward exists.
//
// Conservative SystemVerilog subset only (charter §2). Lint: clean under
// `verilator --lint-only -Wall` (lint_mem_guard CTest).

module zhao_mem_guard
  import zhao_pkg::*;
(
  input  logic clk,
  input  logic rst_n,

  // client port (muxed upstream; the client field identifies the owner)
  input  zhao_guard_req_t req,
  output zhao_guard_rsp_t rsp,

  // region map inputs (CMD.SCHEDULER grants at frame start; deny-all below)
  input  logic        map_valid,     // a blit grant exists this frame
  input  logic        blit_slot,     // 0/1: the leased FB slot
  input  logic [31:0] blit_span,     // granted bytes (canvas_bytes(mode))
  // WHICH WRITER HOLDS THE LEASE. 0 = DEBUG.FRAMEBLIT, 1 = RASTER.FBWRITE.
  // Two blocks now write an inactive framebuffer slot and they share the
  // SPATIAL window but not the TEMPORAL permission: a second overlapping region
  // entry would copy the same address law, cost more plumbing, and still not
  // stop them corrupting each other. VIDEO.SLOTMGR already guarantees one lease
  // at a time with a generation, so the lease is where the writer is named.
  //
  // A v1 frame uses the renderer or DebugFrameBlit, never both.
  //
  // ENFORCED-BY: tests/formal/formal_mem_guard.sv:a1_region
  input  logic        fb_writer,

  // forwarded side (guard -> MEM.VRAM.ARBITER), ready/valid
  output zhao_arb_req_t arb_req,
  input  zhao_arb_rsp_t arb_rsp,

  // events / trace (violations are not a catalog counter; they trace to the
  // harness with the full request — the saved-failing-vector lane)
  output logic           guard_violation,      // one-cycle pulse
  output logic [31:0]    guard_violations,
  output zhao_guard_req_t guard_violation_req   // latched violating request
);

  // ------------------------------------------------------------ verdict ----
  // full contiguous byte mask over len bytes
  function automatic logic [63:0] mask_of(input logic [6:0] len_b);
    mask_of = '0;
    for (int b = 0; b < 64; b++) begin
      if (b < len_b) mask_of[b] = 1'b1;
    end
  endfunction

  logic [31:0] addr32, end32;
  logic        len_ok, be_ok, shape_ok;
  logic        scan_ok, blit_ok, asset_ok;
  logic        pass_ok;

  assign addr32   = {5'b0, req.addr};
  assign end32    = addr32 + {25'b0, req.len};   // 32-bit: cannot wrap the map
  assign len_ok   = (req.len >= 7'd1) && (req.len <= 7'd64);
  assign be_ok    = (req.be == mask_of(req.len));
  assign shape_ok = len_ok && be_ok;

  // scanout: read-only, within EITHER FB slot. The slots are DISJOINT
  // regions since the bank split (zhao_pkg ZHAO_FB_SLOT1_BASE note): the
  // old single-comparison form (end <= SLOT1+SPAN) relied on the slots
  // being contiguous and would have admitted reads from the hole between
  // them. A <=64-B request can never bridge from slot 0 into slot 1, so
  // per-slot containment is exact.
  assign scan_ok = !req.write
                 && ((end32 <= ZHAO_FB_SLOT0_BASE + ZHAO_FB_SLOT_SPAN)
                     || ((addr32 >= ZHAO_FB_SLOT1_BASE)
                         && (end32 <= ZHAO_FB_SLOT1_BASE + ZHAO_FB_SLOT_SPAN)));

  // blit: write-only, within the granted slot window.
  // blit_span is clamped to the slot's own span before use. CMD.SCHEDULER is
  // specified to write canvas_bytes(mode) (<= ZHAO_FB_SLOT_SPAN), but the
  // guard must not TRUST that: an over-large span made blit_base + blit_span
  // wrap 32 bits, and a wrapped window admitted writes far outside the map —
  // an escape, in the one block whose entire contract is that no escape
  // exists. Clamping keeps every legal request legal (they never exceed the
  // slot) and closes the wrap by construction. Removing the clamp fails
  // the proof again (design/formal_runs.yml notes).
  // ENFORCED-BY: tests/formal/mem_guard_no_escape.sby
  logic [31:0] blit_base, blit_end, blit_span_eff;
  assign blit_base     = blit_slot ? ZHAO_FB_SLOT1_BASE : ZHAO_FB_SLOT0_BASE;
  assign blit_span_eff = (blit_span > ZHAO_FB_SLOT_SPAN) ? ZHAO_FB_SLOT_SPAN : blit_span;
  assign blit_end      = blit_base + blit_span_eff;
  // The window check, shared by both writers. `fb_window_ok` is the name the
  // ruling gives it; `blit_ok` is kept as the identifier so the proof's own
  // wording still lines up with the code it proves.
  assign blit_ok       = req.write && map_valid
                         && (addr32 >= blit_base) && (end32 <= blit_end);

  // asset pool: READ-ONLY, ENGINE1's geometry region (spec/memory_rules.md 5f).
  // This is the Phase-3 extension the Phase-2 note promised, and it is the one
  // thing standing between the console and its geometry front end: every
  // MESHFETCH descriptor read was landing on `default: pass_ok = 1'b0`.
  //
  // A THIRD WINDOW IS OPENED HERE, unlike the ENGINE0 change which admitted a
  // client to an existing one -- so it is stated plainly rather than folded in.
  // What keeps the no-escape guarantee intact is that the window is
  // READ-ONLY and its bounds are CONSTANTS: `!req.write` means nothing in this
  // region can alter a frame buffer, and BASE + SPAN is 0x0800_0000 exactly,
  // computed at elaboration, so the wrap the blit clamp exists to prevent
  // cannot arise here. No map input is consulted, so unlike the blit window
  // this one is not frame-scoped and does not depend on `map_valid`.
  // ENFORCED-BY: tests/formal/mem_guard_no_escape.sby
  assign asset_ok = !req.write
                  && (addr32 >= ZHAO_GEOM_ASSET_BASE)
                  && (end32  <= ZHAO_GEOM_ASSET_BASE + ZHAO_GEOM_ASSET_SPAN);

  // terrain page pool: TERRAIN.BUILD's bank-2 region, WRITE for the loader and
  // READ for the writeback (rulings T2 / T3 / T4, spec/memory_rules.md 5b).
  // This is the FOURTH window, and like the asset pool it is stated plainly
  // rather than folded into an existing one.
  //
  // IT IS THE NARROWEST READING OF T2/T4 THAT LETS A PAGE BE LOADED AND ITS
  // DIRTY SHEET BE SAVED AT ALL:
  //   * ONE region of the six T2 names in bank 2. RESIDENT_MIP_POOL,
  //     COMPOSED_HEIGHT, COMPOSED_VELOCITY, WRITEBACK_STAGING and
  //     COMPOSED_MIP_POOL stay unmapped until the blocks that touch them
  //     exist. TERRAIN.PAGELOADER writes pages and nothing else;
  //     TERRAIN.WRITEBACK reads sheets out of those same pages and nothing
  //     else. In particular WRITEBACK_STAGING/journal at 0x0578_0000 stays
  //     unmapped: v1's writeback goes straight across MEM.HPS.BRIDGE, so
  //     opening it would be a hole with a plan attached.
  //   * ONE client. Only ZHAO_CLIENT_TERRAIN_BUILD reaches it (the case arm
  //     below); ENGINE1 does not, DEBUG does not, and the framebuffer writers
  //     do not.
  //   * TWO DIRECTIONS, TWO ARMS, ONE WINDOW. `terrain_ok` REQUIRES
  //     `req.write`; `terrain_rd_ok` REQUIRES `!req.write`; the bounds are the
  //     same two constants. The write arm is TERRAIN.PAGELOADER depositing
  //     pages. The read arm is TERRAIN.WRITEBACK evacuating a dirty layer F,
  //     which T2 places INSIDE the page ("no separate permanent E/F/H pools"),
  //     so there IS no F pool to read and the sheet is reachable only here.
  //     Both are ruled traffic for this one client: T3 names page loads AND
  //     F-sheet writeback as TERRAIN_BUILD's, and T4 REQUIRES the writeback.
  //     Client id 5 stays unspent because T3 forbids spending it pre-emptively,
  //     so a second client id for the reader was neither available nor narrower
  //     -- it would have put two clients in one region.
  //
  //     `terrain_ok || terrain_rd_ok` is the window test with the direction bit
  //     factored back out, and one comparison would synthesise identically. The
  //     arms are kept SEPARATE because the PROOF states them separately: two
  //     theorems name WHICH direction regressed, and a merged arm would satisfy
  //     both non-vacuity covers while proving neither.
  //
  //     THE READ WAS WITHHELD UNTIL ITS BLOCK EXISTED, and this comment is
  //     where that promise was made: "when the block that does it exists, it
  //     brings its own arm and its own proof. Admitting the read now would
  //     admit it for a writeback path that has never been written."
  //     `fpga/rtl/terrain/zhao_terrain_writeback.sv` now exists, is registered
  //     in tools/rtl/check_guard_verdict.py's client list, and reads exactly
  //     the 64-byte page header plus the 129 chunks spanning layer F -- 130
  //     requests per sheet, asserted as an exact count by its bench.
  //
  //     A READ CANNOT ALTER A FRAME BUFFER. That is the GEOM.ASSET_POOL
  //     argument and it holds twice over here: a forwarded read carries no
  //     write data at all, and this window's CONSTANT bounds are disjoint from
  //     both framebuffer slots (0x0000_0000 and 0x0200_0000) and from the asset
  //     pool. The widening is confined to bank 2, and the no-escape theorem is
  //     unchanged in meaning -- what changes is one direction bit, for one
  //     client, over one region it already owned.
  //   * CONSTANT BOUNDS. No map input is consulted, so this window is not
  //     frame-scoped and cannot be moved by a grant; BASE + SPAN is
  //     0x054E_0000 exactly, computed at elaboration, so the wrap the blit
  //     clamp exists to prevent cannot arise here.
  //
  // WHAT THIS WINDOW DOES **NOT** DO, SAID OUT LOUD.
  // T2 asks for STATE-AWARE permission -- "a loader may write only a LOADING
  // slot" -- and this is not that. The guard has one muxed request port and no
  // residency context; knowing which slot is LOADING means a 1,024-entry state
  // shadow plus an address-to-slot decode by 21,376 (not a power of two) on the
  // verdict path of the block whose counter enable was already the largest
  // negative-slack family in the composed shell. The interface that would carry
  // that state -- who owns the bitmap, how it crosses to the guard, what a
  // stale copy means -- is NOT ruled anywhere, so it is not invented here.
  //
  // The residual, precisely: a faulty TERRAIN.BUILD may write a page slot other
  // than the one it was told to load. It cannot touch a framebuffer, cannot
  // touch the asset pool, cannot touch the rest of bank 2, and cannot leave the
  // map -- so the no-escape theorem is unchanged and the worst case is corrupt
  // GROUND for one page, caught by the CRC the directory checks before it
  // publishes. TERRAIN.PAGELOADER already refuses an out-of-pool slot itself
  // (its slot index is one bit wider than the pool so the refusal is reachable
  // rather than truncated). Tightening this to the LOADING slot is a separate,
  // ruled piece of work and it needs the residency-to-guard interface first.
  //
  // THE NEW RESIDUAL THE READ ARM CREATES, said out loud like the write one.
  // Client 6 may now read ANY page in the pool, so a faulty writeback could
  // journal ANOTHER PATCH'S scars into the HPS journal. MEM.GUARD cannot see
  // that -- it is the same state-awareness gap as the write side, for the same
  // reason, and it is NOT closed here. It is answered one block up:
  // TERRAIN.WRITEBACK reads the evicted page's 64-byte HEADER FIRST and refuses
  // (`kSheetHeaderIdent`) before a single journal byte moves, if
  // {island_id, patch_ix, patch_iz} does not match the job. That is
  // spec/terrain_rules.md 2.1's "redundancy is a corruption check" spent on
  // exactly the failure this arm creates, and it costs one 64-byte read of 130.
  // ENFORCED-BY: tests/formal/mem_guard_no_escape.sby
  logic terrain_ok, terrain_rd_ok;
  assign terrain_ok = req.write
                    && (addr32 >= ZHAO_TERRAIN_PAGE_POOL_BASE)
                    && (end32  <= ZHAO_TERRAIN_PAGE_POOL_BASE
                                  + ZHAO_TERRAIN_PAGE_POOL_SPAN);
  // The READ arm. Same two constants, opposite direction bit, deliberately a
  // SEPARATE assign so the two directions stay two theorems.
  assign terrain_rd_ok = !req.write
                       && (addr32 >= ZHAO_TERRAIN_PAGE_POOL_BASE)
                       && (end32  <= ZHAO_TERRAIN_PAGE_POOL_BASE
                                     + ZHAO_TERRAIN_PAGE_POOL_SPAN);

  // ONE WINDOW, ONE OWNER AT A TIME. Both writers are checked against the same
  // clamped slot span; what separates them is which one the lease names. A
  // writer without the lease is refused exactly as a request outside the window
  // is, and the region this block guarantees nothing escapes is unchanged.
  always_comb begin
    unique case (req.client)
      ZHAO_CLIENT_SCANOUT:  pass_ok = shape_ok && scan_ok;
      ZHAO_CLIENT_BLIT_DMA: pass_ok = shape_ok && blit_ok && (fb_writer == 1'b0);
      ZHAO_CLIENT_ENGINE0:  pass_ok = shape_ok && blit_ok && (fb_writer == 1'b1);
      ZHAO_CLIENT_ENGINE1:  pass_ok = shape_ok && asset_ok;
      ZHAO_CLIENT_TERRAIN_BUILD: pass_ok = shape_ok && (terrain_ok || terrain_rd_ok);
      default: pass_ok = 1'b0;      // DEBUG still owns nothing, and neither
                                    // does the unspent client 5
    endcase
  end

  // --------------------------------------------------------- forwarding ----
  // a passing request is latched and presented to the arbiter until granted;
  // ready/valid end-to-end: the guard is ready exactly when its forwarding
  // stage is free (an offered request is held upstream, never dropped)
  logic           fwd_active;
  zhao_arb_req_t  fwd_req;

  always_comb begin
    arb_req       = fwd_req;
    arb_req.valid = fwd_active;
  end

  // `rsp` gets exactly ONE kind of driver. Continuously assigning rsp.ready
  // while driving rsp.ok/rsp.violation from the always_ff below mixes a
  // continuous and a procedural driver on one variable, which IEEE 1800
  // forbids (a variable may be written by procedural statements OR by a
  // single continuous assignment, never both) — packed struct fields are not
  // separate variables. Tools that accept it resolve the struct
  // inconsistently: in the elaborated formal model arb_req.valid became
  // unreachable, which silently made the no-escape assertions VACUOUS.
  // The verdict bits are registered here and the whole struct is assembled
  // by this single always_comb.
  logic rsp_ok_q, rsp_violation_q;
  always_comb begin
    rsp.ready     = !fwd_active;   // level; verdict 1 cycle after accept
    rsp.ok        = rsp_ok_q;
    rsp.violation = rsp_violation_q;
  end

  // ------------------------------------------------------------- seq core --
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      fwd_active          <= 1'b0;
      fwd_req             <= '0;
      rsp_ok_q            <= 1'b0;
      rsp_violation_q     <= 1'b0;
      guard_violation     <= 1'b0;
      guard_violations    <= 32'd0;
      guard_violation_req <= '0;
    end else begin
      // defaults: one-cycle verdict pulses
      rsp_ok_q         <= 1'b0;
      rsp_violation_q  <= 1'b0;
      guard_violation  <= 1'b0;

      // THE COUNTER FOLLOWS THE PULSE, NOT THE DECISION.
      //
      // `guard_violations` used to increment in the same cycle as the verdict,
      // which put the whole range-check chain -- the requester's address, the
      // end address, four bounds compares, the client case -- on the ENABLE of
      // a 32-bit register bank. The full negative-slack census made it the
      // largest remaining family in the composed shell:
      //
      //   1,383 paths  scanout|fetch -> mem_guard|guard_violations   -0.195
      //
      // It counts the same events either way. `guard_violation` is already the
      // registered one-cycle pulse for exactly this verdict, so counting off
      // IT costs one cycle of latency on an observability counter and takes
      // the comparison chain off the counter entirely.
      //
      // The SAFETY path is untouched: rsp_ok_q, rsp_violation_q, fwd_active
      // and fwd_req still resolve in the accepting cycle, which is what
      // tests/formal/mem_guard_no_escape.sby proves about.
      if (guard_violation) guard_violations <= guard_violations + 32'd1;

      // forwarded request leaves when the arbiter accepts it
      if (fwd_active && arb_rsp.grant) fwd_active <= 1'b0;

      // accept at most one request per cycle (rsp.ready level above)
      if (req.valid && !fwd_active) begin
        if (pass_ok) begin
          rsp_ok_q          <= 1'b1;
          fwd_active        <= 1'b1;
          fwd_req.write     <= req.write;
          fwd_req.client    <= req.client;
          fwd_req.addr      <= req.addr;
          fwd_req.len       <= req.len;
        end else begin
          rsp_violation_q     <= 1'b1;
          guard_violation     <= 1'b1;
          guard_violation_req <= req;   // full request traced to the harness
        end
      end
    end
  end

  // arb_rsp.credits is not consumed here (the guard is request-path only;
  // the arbiter owns credit law) — keep the frozen port type and silence
  // the field-unused lint.
  /* verilator lint_off UNUSEDSIGNAL */
  logic [7:0] unused_arb_credits;
  assign unused_arb_credits = arb_rsp.credits;
  /* verilator lint_on UNUSEDSIGNAL */

endmodule
