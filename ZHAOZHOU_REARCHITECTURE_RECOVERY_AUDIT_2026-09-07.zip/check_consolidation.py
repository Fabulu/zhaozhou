#!/usr/bin/env python3
"""Independent arithmetic/accounting checks for the consolidated handoff.

Does not compile RTL, simulate service timing, prove a drain protocol, or run
Quartus. All integer arithmetic here is unbounded unless explicitly masked.
"""
from __future__ import annotations
import hashlib
import json
from pathlib import Path
import random

MIN32 = -(1 << 31)
MAX32 = (1 << 31) - 1
MODULUS = 1 << 14
MASK = MODULUS - 1


def sat32(x: int) -> int:
    return max(MIN32, min(MAX32, x))


def public_owner(sequence: int) -> int:
    return ((sequence & 63) << 8) | ((sequence >> 6) & 255)


def sequence_of(owner: int) -> int:
    return ((owner & 255) << 6) | ((owner >> 8) & 63)


def coarse_height(ha: int, hb: int) -> int:
    return sat32(ha + sat32((hb - ha + 1) >> 1))


def morph_height(h: int, hc: int, factor: int) -> int:
    return sat32(h + sat32(((hc - h) * factor + 32768) >> 16))


def run() -> dict:
    if not __debug__:
        raise RuntimeError("Assertions must be enabled; do not run with python -O")
    results: dict = {}
    for sequence in range(MODULUS):
        assert sequence_of(public_owner(sequence)) == sequence
    results['full_handle_roundtrips'] = MODULUS

    generations = [0] * 64
    sequence = 64
    fences = 0
    for n in range(35000):
        slot = n % 64
        if sequence == 0:
            fences += 1  # boundary count only: no external-drain model here
        generations[slot] = (generations[slot] + 1) & 255
        assert public_owner(sequence) == ((slot << 8) | generations[slot])
        sequence = (sequence + 1) & MASK
    results['legacy_handle_sequence_allocations'] = 35000
    results['namespace_boundaries_encountered_not_protocol_proved'] = fences
    assert fences == 2

    small_cases = 0
    for head in range(32):
        for used in range(9):
            explicit = {(head + k) % 32 for k in range(used)}
            for candidate in range(32):
                assert (((candidate - head) % 32) < used) == (candidate in explicit)
                small_cases += 1
    results['reduced_namespace_exhaustive_membership_cases'] = small_cases

    rng = random.Random(20260907)
    heads = sorted(set([0, 1, 63, 64, 127, 16319, 16320, 16321, 16382, 16383]
                       + [rng.randrange(MODULUS) for _ in range(128)]))
    membership_cases = reconstructions = 0
    for head in heads:
        for used in range(65):
            ordered = [(head + k) & MASK for k in range(used)]
            explicit = set(ordered)
            probes = [(head + k) & MASK for k in (-163, -65, -64, -1, 0, 1, 62, 63, 64, 65, 163)]
            probes += [(head + used - 1) & MASK, (head + used) & MASK]
            probes += [rng.randrange(MODULUS) for _ in range(4)]
            for candidate in probes:
                assert (((candidate - head) & MASK) < used) == (candidate in explicit)
                membership_cases += 1
            for expected in ordered:
                slot = expected & 63
                offset = (slot - (head & 63)) & 63
                assert offset < used
                assert ((head + offset) & MASK) == expected
                reconstructions += 1
    results['full_width_membership_cases'] = membership_cases
    results['leased_slot_reconstructions'] = reconstructions
    results['full_width_tested_heads'] = len(heads)

    # A negative witness: a stale sequence exactly one slot ring away aliases
    # when the full membership subtraction is truncated to the low six bits.
    head, used, stale = 64, 1, 0
    assert not (((stale - head) & MASK) < used)
    assert ((stale - head) & 63) < used
    results['truncated_membership_negative_witness'] = {'head': head, 'used': used, 'stale': stale}

    # Physical locations of one owned queue ticket; no external pop.
    states = [(1, 0, 0, 0), (0, 1, 0, 0), (0, 0, 1, 0)]
    assert all(sum(s) == 1 for s in states)
    visible_only = [b + h + s for b, pending, h, s in states]
    assert visible_only == [1, 0, 1]
    results['pending_read_false_empty_witness'] = visible_only

    coarse = coarse_height(MIN32, MAX32)
    averaged = (MIN32 + MAX32 + 1) >> 1
    full_morph = morph_height(MIN32, MAX32, 65536)
    assert (coarse, averaged, full_morph) == (-1, 0, -1)
    positive = sat32((32768 + 32768) >> 16)
    negative = sat32((-32768 + 32768) >> 16)
    assert (positive, negative, -positive) == (1, 0, -1)
    results['terrain_saturation_witnesses'] = {
        'staged_coarse': coarse, 'single_average': averaged,
        'full_morph_result': full_morph, 'coarse_target': MAX32,
        'rounded_positive_normal': positive, 'rounded_negative_normal': negative,
        'negated_rounded_positive': -positive,
    }

    rounding_cases = 0
    for shift in (1, 8, 16):
        for _ in range(20000):
            x = rng.randrange(-(1 << 65), 1 << 65)
            assert ((x + (1 << (shift - 1))) >> shift) == ((x >> shift) + ((x >> (shift - 1)) & 1))
            rounding_cases += 1
    results['unbounded_signed_rounding_identity_cases'] = rounding_cases

    banks = [19, 8, 3, 2, 4, 4, 6, 6, 1, 1, 1, 0, 1, 1, 2, 3, 1, 6]
    assert sum(banks) == 69
    assert 64 - 3 + 2 + 6 == 69
    assert 64*64 + 3*64*40 + 64*40 + 64*40 == 16896
    assert 16896 + 3*64*14 == 19584
    assert 21*64 == 1344 and 30*64 == 1920
    assert 4*(14 + 4*40) + 4*(14+40+64) == 1168
    old_registers = [13459, 3211, 3030, 2955, 1025, 953, 832, 784, 723, 402, 183, 34]
    assert sum(old_registers) == 27591
    assert 27973 - sum(old_registers) == 382
    results['inventory_checks'] = {'proposed_m10k': sum(banks), 'owner_persistent_bits': 16896,
                                   'old_owner_memory_bits': 19584, 'old_census_unattributed_registers': 382}
    results['status'] = 'PASS'
    results['scope'] = 'Independent integer/representation/accounting checks only; no RTL or physical execution'
    results['script_sha256'] = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    return results


if __name__ == '__main__':
    output = Path(__file__).with_name('consolidation_checks.json')
    data = run()
    output.write_text(json.dumps(data, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(data, indent=2))
