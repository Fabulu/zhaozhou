ZHAOZHOU REARCHITECTURE RECOVERY — 7 SEPTEMBER 2026

START WITH ZHAOZHOU_MASTER_REARCHITECTURE_RECOVERY_2026-09-07.txt.
It is the consolidated implementation handoff. Its opening priority and receiver
acknowledgement are intended for the ACTIVE hardware session, not merely an
unread commit on another branch.

The audit identified three owner uploads: two texture briefs already on the
inspected hardware branch and one explicitly deferred terrain brief on main.
The TXT preserves their technical requirements and resolves conflicting proposed
control profiles. It is not a literal concatenation of all original code
appendices. It does not alter the repository or deliver instructions to another
running session by itself.

Evidence files:
  owner_sources.json — exact owner report commit/path/Git-blob identifiers.
  branches.json — all 40 branch snapshots and owner/day search URLs/results.
  supporting_sources.json — pinned implementation/report evidence map.
  check_consolidation.py — independently executed integer/accounting checks.
  consolidation_checks.json — actual check results and script hash.
  document_qa.json — document size, reference/identifier/structure checks.
  recover_original_reports.py — optional exact-byte original report exporter.
  SHA256SUMS.txt — hashes of delivered files except this hash list itself.

Original report recovery:
  python recover_original_reports.py --repo /path/to/zhaozhou \
      --out /path/outside/repository/recovered-owner-reports

The exporter reads local Git objects first, otherwise immutable public raw URLs.
Use --offline to forbid network fallback. It verifies each original Git blob
before writing to a NEW output directory. It exports all three complete source
reports and ALL_ORIGINAL_OWNER_REPORTS.txt, including original code appendices.
It does not check out, merge, reset, stage, commit or push. In this delivery its
syntax and --help were checked; network/source export was NOT executed here.

Model check:
  python check_consolidation.py

Those checks do not compile RTL, run Verilator, prove adapter drain handshakes,
or synthesize/fit anything. No new Quartus result is claimed.
