#!/usr/bin/env python3
"""Export the three byte-verified original owner reports, including code appendices.

Read-only with respect to the Git worktree: first try `git show COMMIT:PATH`;
otherwise read the pinned public GitHub raw URL. Writes only to a NEW output
folder and never checks out, merges, resets, stages, commits, or pushes.

Example:
    python recover_original_reports.py --repo /path/to/zhaozhou \
        --out /path/outside/repository/recovered-owner-reports

Network export was not performed in the artifact-creation environment.
"""
from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
from urllib.error import HTTPError, URLError
from urllib.parse import quote
from urllib.request import Request, urlopen


def git_blob_sha(data: bytes) -> str:
    return hashlib.sha1(b'blob ' + str(len(data)).encode('ascii') + b'\0' + data).hexdigest()


def from_git(repo: Path | None, commit: str, path: str) -> bytes | None:
    if repo is None:
        return None
    try:
        result = subprocess.run(['git', '-C', str(repo), 'show', f'{commit}:{path}'],
                                stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                check=False, timeout=30)
    except (FileNotFoundError, subprocess.TimeoutExpired):
        return None
    return result.stdout if result.returncode == 0 else None


def retrieve(record: dict, repo: Path | None, offline: bool) -> tuple[bytes, str]:
    data = from_git(repo, record['commit'], record['path'])
    source = 'local Git object'
    if data is None:
        if offline:
            raise RuntimeError(f"{record['id']}: pinned object is unavailable locally; offline mode forbids a network read")
        url = ('https://raw.githubusercontent.com/Fabulu/zhaozhou/'
               + record['commit'] + '/' + quote(record['path'], safe='/'))
        try:
            with urlopen(Request(url, headers={'User-Agent': 'Zhaozhou-report-recovery/1.0'}), timeout=45) as r:
                data = r.read(4 * 1024 * 1024 + 1)
            if len(data) > 4 * 1024 * 1024:
                raise RuntimeError('Unexpected source size exceeds the 4 MiB safety limit')
        except (HTTPError, URLError, TimeoutError) as exc:
            raise RuntimeError(f"{record['id']}: could not read pinned public source: {exc}") from exc
        source = url
    actual = git_blob_sha(data)
    if actual != record['blob']:
        raise RuntimeError(f"{record['id']}: Git blob mismatch: expected {record['blob']}, got {actual}; refusing export")
    # Check before any output is written; no lossy decoding.
    data.decode('utf-8')
    if record.get('bytes') is not None and len(data) != record['bytes']:
        raise RuntimeError(f"{record['id']}: byte-count mismatch despite manifest; refusing export")
    return data, source


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('--repo', type=Path, help='Optional existing zhaozhou checkout; only git show is used')
    ap.add_argument('--out', type=Path, required=True, help='New output directory, not an existing worktree directory')
    ap.add_argument('--offline', action='store_true', help='Never use network fallback')
    args = ap.parse_args()
    target = args.out.expanduser().resolve()
    if target.exists():
        ap.error('Output directory already exists. Choose a new path; no files will be overwritten.')
    if args.repo:
        repo = args.repo.expanduser().resolve()
        if not repo.is_dir():
            ap.error('Repository directory does not exist.')
        # Refuse writing inside the checkout provided by the operator.
        if target == repo or repo in target.parents:
            ap.error('Output must be outside the supplied repository checkout.')
    else:
        repo = None
    manifest = Path(__file__).with_name('owner_sources.json')
    records = json.loads(manifest.read_text(encoding='utf-8'))
    recovered = [(r, *retrieve(r, repo, args.offline)) for r in records]
    # All bytes and hashes are validated before creating the export directory.
    target.mkdir(parents=True, exist_ok=False)
    combined = bytearray(
        b'ZHAOZHOU ORIGINAL OWNER REPORTS -- 2026-09-07\n'
        b'Verbatim source bodies with wrapper provenance. Historic/proposed instructions\n'
        b'can conflict; use the consolidated handoff for current precedence.\n\n')
    outputs = []
    for r, data, source in recovered:
        filename = f"{r['id']}__{Path(r['path']).name}"
        (target / filename).write_bytes(data)
        heading = (f"\n{'='*76}\nBEGIN {r['id']} | {r['path']}\n"
                   f"Commit {r['commit']}\nGit blob {r['blob']}\n"
                   f"{'='*76}\n")
        combined.extend(heading.encode('utf-8'))
        combined.extend(data)
        combined.extend(f"\nEND {r['id']}\n".encode('utf-8'))
        outputs.append({'id': r['id'], 'filename': filename, 'commit': r['commit'],
                        'git_blob': r['blob'], 'sha256': hashlib.sha256(data).hexdigest(),
                        'bytes': len(data), 'read_from': source})
    (target / 'ALL_ORIGINAL_OWNER_REPORTS.txt').write_bytes(bytes(combined))
    (target / 'recovery_manifest.json').write_text(json.dumps(outputs, indent=2) + '\n', encoding='utf-8')
    print(f'Exported {len(outputs)} verified reports and their combined text to {target}')


if __name__ == '__main__':
    try:
        main()
    except (OSError, ValueError, RuntimeError, UnicodeError) as exc:
        raise SystemExit(f'Recovery failed without modifying the Git worktree: {exc}')
